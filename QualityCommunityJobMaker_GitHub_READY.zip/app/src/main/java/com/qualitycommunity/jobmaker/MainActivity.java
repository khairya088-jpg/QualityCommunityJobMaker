package com.qualitycommunity.jobmaker;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.provider.MediaStore;
import android.view.*;import android.widget.*;import java.io.*;import java.util.*;import java.util.regex.*;

public class MainActivity extends Activity{
 EditText raw; ImageView preview; TextView parsed; Bitmap template,result;
 String job="",company="",location="",qualification="",experience="",requirements="",apply="";
 public void onCreate(Bundle b){super.onCreate(b);ScrollView sv=new ScrollView(this);LinearLayout r=new LinearLayout(this);
 r.setOrientation(LinearLayout.VERTICAL);r.setPadding(28,28,28,40);r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sv.addView(r);setContentView(sv);
 TextView h=t("QC  Quality Community",27,true);h.setTextColor(Color.rgb(7,61,131));r.addView(h);r.addView(t("الصق إعلان الوظيفة كاملًا — والتطبيق يفنّطه تلقائيًا",16,false));
 raw=new EditText(this);raw.setHint("الصق الإعلان هنا كما هو من فيسبوك أو واتساب أو أي موقع...");raw.setMinLines(10);raw.setGravity(Gravity.TOP|Gravity.RIGHT);
 raw.setTextSize(17);raw.setPadding(20,20,20,20);raw.setBackgroundColor(Color.rgb(246,249,253));r.addView(raw);
 Button make=btn("✨ تحليل الإعلان وإنشاء التصميم");r.addView(make);
 parsed=t("",15,false);parsed.setGravity(Gravity.RIGHT);parsed.setPadding(10,18,10,18);r.addView(parsed);
 preview=new ImageView(this);preview.setAdjustViewBounds(true);r.addView(preview);
 Button save=btn("⬇ حفظ الصورة PNG");r.addView(save);
 template=BitmapFactory.decodeResource(getResources(),R.drawable.quality_community_template);
 make.setOnClickListener(v->{parse(raw.getText().toString());render();});save.setOnClickListener(v->{if(result==null){parse(raw.getText().toString());render();}save();});
 }
 TextView t(String s,int z,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setGravity(Gravity.CENTER);if(b)v.setTypeface(null,1);v.setPadding(4,8,4,8);return v;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(17);b.setAllCaps(false);return b;}
 void parse(String s){
  String[] ls=s.replace("•","\n").split("\\n"); ArrayList<String> req=new ArrayList<>(); job=company=location=qualification=experience=apply="";
  for(String q:ls){String x=q.trim();if(x.isEmpty())continue;String l=x.toLowerCase();
   if(apply.isEmpty()&&(x.contains("@")||l.contains("للتقديم")||l.contains("ارسال")||l.contains("إرسال")||l.contains("واتساب")||l.contains("whatsapp")))apply=x;
   else if(location.isEmpty()&&(l.contains("الموقع")||l.contains("مكان العمل")||l.contains("location")||l.contains("العبور")||l.contains("القاهرة")||l.contains("الجيزة")||l.contains("اسكندرية")||l.contains("الإسكندرية")))location=clean(x);
   else if(experience.isEmpty()&&(l.contains("خبر")||l.contains("experience")||l.contains("سنوات")))experience=clean(x);
   else if(qualification.isEmpty()&&(l.contains("بكالور")||l.contains("مؤهل")||l.contains("علوم")||l.contains("هندسة")))qualification=clean(x);
   else if(company.isEmpty()&&(l.contains("شركة")||l.contains("company")))company=clean(x);
   else if(job.isEmpty()&&(l.contains("مهندس")||l.contains("كيميائي")||l.contains("مدير")||l.contains("مراقب")||l.contains("quality")||l.contains("chemist")||l.contains("engineer")))job=clean(x);
   else req.add(x);
  }
  if(job.isEmpty()&&ls.length>0)job=ls[0].trim();
  requirements=join(req,5);
  parsed.setText("البيانات المستخرجة تلقائيًا\n\nالمسمى: "+job+"\nالشركة: "+company+"\nالموقع: "+location+"\nالمؤهل: "+qualification+"\nالخبرة: "+experience+"\nطريقة التقديم: "+apply);
 }
 String clean(String x){return x.replaceFirst("^[^:：]{1,20}[:：]\\s*","").trim();}
 String join(ArrayList<String>a,int max){StringBuilder z=new StringBuilder();for(int i=0;i<a.size()&&i<max;i++){if(z.length()>0)z.append("\n");z.append(a.get(i));}return z.toString();}
 void render(){int W=1024,H=1536;result=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(result);c.drawColor(Color.WHITE);
  if(template!=null)c.drawBitmap(template,null,new Rect(0,0,W,H),null);Paint p=new Paint(1);int y=330;
  y=center(c,p,job,y,52,Color.rgb(8,60,128));y=center(c,p,company,y+12,34,Color.rgb(23,43,67));y=center(c,p,location,y+8,28,Color.DKGRAY)+30;
  y=sec(c,p,"المؤهل",qualification,y);y=sec(c,p,"الخبرة",experience,y);y=sec(c,p,"المتطلبات",requirements,y);sec(c,p,"طريقة التقديم",apply,y);preview.setImageBitmap(result);
 }
 int center(Canvas c,Paint p,String s,int y,int z,int col){if(s.trim().isEmpty())return y;p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(z);p.setColor(col);
  for(String q:wrap(p,s,760)){c.drawText(q,512,y,p);y+=(int)(z*1.25);}return y;}
 int sec(Canvas c,Paint p,String lab,String s,int y){if(s.trim().isEmpty())return y;p.setTextAlign(Paint.Align.RIGHT);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(30);p.setColor(Color.rgb(8,116,216));c.drawText(lab,880,y,p);y+=43;
  p.setTypeface(Typeface.DEFAULT);p.setTextSize(27);p.setColor(Color.rgb(23,43,67));for(String q:wrap(p,s,735)){c.drawText(q,880,y,p);y+=39;}return y+18;}
 ArrayList<String> wrap(Paint p,String s,float m){ArrayList<String>o=new ArrayList<>();for(String pa:s.split("\\n")){String line="";for(String w:pa.trim().split("\\s+")){String z=line.isEmpty()?w:line+" "+w;if(p.measureText(z)>m&&!line.isEmpty()){o.add(line);line=w;}else line=z;}if(!line.isEmpty())o.add(line);}return o;}
 void save(){try{ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"QC_Job_"+System.currentTimeMillis()+".png");v.put(MediaStore.Images.Media.MIME_TYPE,"image/png");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Quality Community");
  android.net.Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);OutputStream os=getContentResolver().openOutputStream(u);result.compress(Bitmap.CompressFormat.PNG,100,os);os.close();Toast.makeText(this,"تم حفظ التصميم",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
}