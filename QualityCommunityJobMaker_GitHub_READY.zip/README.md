# Quality Community Job Maker
Android app for pasting a complete job advert, automatically classifying common fields using local inference rules, rendering them into the fixed Quality Community template, and saving a PNG.

## Build APK on GitHub
Open **Actions → Build Android APK → Run workflow**. After completion, download the `QualityCommunity-APK` artifact.

No API key is required in this version.
